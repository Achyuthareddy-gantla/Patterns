package demo13;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class Demo13 {
	public static void main (String[] args) {
        ArrayList<String> al = new ArrayList<String>();
        al.add("1");
        al.add("2");
        al.add("3");
        al.add("4");
        System.out.println("ArrayList elements are:");
        Iterator itr = al.iterator();
        while (itr.hasNext())
            System.out.println(itr.next());
  
        Vector<String> v1 = new Vector<String>();
        v1.addElement("5");
        v1.addElement("6");
        v1.addElement("7");
        v1.addElement("8");
        System.out.println("\nVector elements are:");
        Enumeration<String> e1 = v1.elements();
        while (e1.hasMoreElements())
           System.out.println(e1.nextElement());
    }

}

package demo12;

public class Demo12 {
	

	protected void finalize() throws Throwable { 
		try {
			System.out.println("This is a try Block");
			}
			finally {
			System.out.println("This is a finally block");
			}
		}

	public static void main(String[] args) throws Throwable {
	final int abc=10;
	System.out.println(abc);
	Demo12 def= new Demo12();
	def.finalize();
	
		}
}

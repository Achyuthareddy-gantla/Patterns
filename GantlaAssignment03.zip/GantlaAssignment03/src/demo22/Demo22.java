package demo22;

public class Demo22 {

	public static void main(String args[]) {
		String s1="hello";
		String s2="world "+s1;
		System.out.println(s2);
		System.out.println(s1);
		
		
	}
}

package demo17;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


public class Demo17 {
	public static void main(String[] args) {
	
	List<Integer> list1 = new CopyOnWriteArrayList<>();
	list1.add(1);
	list1.add(2);
	list1.add(3);

	Iterator<Integer> itr1 = list1.iterator();

	while (itr1.hasNext()) {
	    Integer a1 = itr1.next();
	    System.out.println(a1);
	    list1.remove(a1); // modification during iteration
	}
	List<Integer> list2 = new ArrayList<>();
	list2.add(1);
	list2.add(2);
	list2.add(3);

	Iterator<Integer> itr = list2.iterator();

	while (itr.hasNext()) {
	    Integer a1 = itr.next();
	    System.out.println(a1);
	    list2.remove(a1); // modification during iteration
	}
	
  }
	
}

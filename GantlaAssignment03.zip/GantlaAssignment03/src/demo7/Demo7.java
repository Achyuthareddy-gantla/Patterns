package demo7;

public class Demo7 {
	
	public Demo7() {
		System.out.println("Illegal modifier for the "
				+ "constructor in type Demo7; only public, protected & private are permitted...So, "
				+ "I have chnaged the final to public to just prevent an error in the class and have added the code with final constructor in doc");
	}

}

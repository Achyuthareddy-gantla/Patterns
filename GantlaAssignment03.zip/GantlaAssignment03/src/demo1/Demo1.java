package demo1;

public class Demo1<T> {
		   private T data;

		   public Demo1(T data) {
		      this.data = data;
		   }

		   public T getData() {
		      return this.data;
		   }

		   public void setData(T data) {
		      this.data = data;
		   }
}

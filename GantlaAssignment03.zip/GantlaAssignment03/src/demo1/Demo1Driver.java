package demo1;

public class Demo1Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo1<Integer> a = new Demo1<>(10);
		a.setData(20);
		System.out.println(a.getData());
	}

}

package demo3;

public class Demo3 {
	    public Demo3 draw() {
	        System.out.println("Drawing shape...");
	        return new Demo3();
	    }
	}

	class Circle extends Demo3 {
	    @Override
	    public Circle draw() {
	        System.out.println("Drawing circle...");
	        return new Circle();
	    }
	}

	class Rectangle extends Demo3 {
	    @Override
	    public Rectangle draw() {
	        System.out.println("Drawing rectangle...");
	        return new Rectangle();
	    }
	}



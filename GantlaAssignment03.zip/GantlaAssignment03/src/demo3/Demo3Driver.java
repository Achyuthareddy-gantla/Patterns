package demo3;

public class Demo3Driver {

	public static void main(String[] args) {
		        Demo3 shape = new Demo3();
		        Circle circle = new Circle();
		        Rectangle rectangle = new Rectangle();

		        Demo3 Shape = shape.draw(); // returns a Shape
		        Demo3 Circle = circle.draw(); // returns a Circle
		        Demo3 Rectangle = rectangle.draw(); // returns a Rectangle

		        System.out.println(Shape.getClass()); // prints "class Shape"
		        System.out.println(Circle.getClass()); // prints "class Circle"
		        System.out.println(Rectangle.getClass()); // prints "class Rectangle"
		    }
}

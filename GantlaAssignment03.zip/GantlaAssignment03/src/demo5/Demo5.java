package demo5;

public class Demo5 {
	    public static void main(String[] args){  
	        StringBuffer buffer=new StringBuffer("hello");  
	        buffer.append("java");  
	        System.out.println(buffer);  
	        System.out.println(System.nanoTime());
	        
	        StringBuilder builder=new StringBuilder("hello");  
	        builder.append("java");  
	        System.out.println(builder);  
	        System.out.println(System.nanoTime());
	    }   
}

package demo15;

import java.util.HashMap;
import java.util.Hashtable;

public class Demo15 {
	    public static void main(String[] args) {
	        Hashtable<String, Integer> h1 = new Hashtable<>();
	        h1.put("apple", 12);
	        h1.put("ball", 13);
	        h1.put("cat", 14);

	        for (String name : h1.keySet()) {
	            int h2 = h1.get(name);
	            System.out.println(name + "'fruits are: " + h2);
	        }
	        System.out.println("Using HashMap");
	    HashMap<String, Integer> fruits = new HashMap<>();
	    fruits.put("apple", 12);
        fruits.put("ball", 13);
        fruits.put("cat", 14);

        for (String abc : fruits.keySet()) {
            int h2 = fruits.get(abc);
            System.out.println(abc + "'fruits are: " + h2);
        }
	 }  

}
